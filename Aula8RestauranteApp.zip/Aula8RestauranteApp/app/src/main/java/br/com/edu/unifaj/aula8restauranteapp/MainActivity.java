package br.com.edu.unifaj.aula8restauranteapp;

import android.os.Bundle;
import android.view.PixelCopy;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }// fim do oncreate


public void AtualizarJson(View v) {
    //Pega as informaçoes da Tela
    //busca o id dos editText
    EditText produtoET = findViewById(R.id.editText_Produto);
    EditText quantidadeET = findViewById(R.id.editText_quantidade);
    EditText valorET = findViewById(R.id.editText_Valor);
    EditText clienteET = findViewById(R.id.editText_Cliente);
    EditText idET = findViewById(R.id.editText_idMesa);

    //converte em seus tipos de memoria
    String nome = produtoET.getText().toString();
    int quantidade = quantidadeET.getText().toString().isEmpty() ? 0 : Integer.parseInt(quantidadeET.getText().toString());
    double valor = valorET.getText().toString().isEmpty() ? 0.0 : Double.parseDouble(valorET.getText().toString());
    String cliente = clienteET.getText().toString();
    String id = idET.getText().toString();

    //criar o JSON
    try {
        JSONObject pedidoObj = new JSONObject();
        pedidoObj.put("nomeProduto", nome);
        pedidoObj.put("quantidade", quantidade);
        pedidoObj.put("valor", valor);

        JSONArray pedidoArray = new JSONArray();
        pedidoArray.put(pedidoObj);

        JSONObject obj = new JSONObject();
        obj.put("cliente", cliente);
        obj.put("pedido", pedidoArray);
        String json = obj.toString();

        //Enviar para o servidor
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="http://192.168.1.101:8080/api/restaurant/mesa/"+id;
        StringRequest stringRequest = new StringRequest(
                Request.Method.PUT, url,
                ok -> tratarResposta(ok) , erro -> tratarErro(erro)) {
            @Override public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }
            @Override
            public byte[] getBody()  {
                try {
                    return json.getBytes("utf-8");
                } catch (Exception ex) {
                    ex.printStackTrace();
                    return null;
                }
            }
        };
        queue.add(stringRequest);
    }catch (Exception ex){
        Toast.makeText(this,"Error" + ex.getMessage(), Toast.LENGTH_LONG).show();
}
}//fim do enviar


    public void abrirMesa(View v){
    //buscar o id da mesa
    EditText idET = findViewById(R.id.editText_idMesa);
    String id = idET.getText().toString();
    if(id == null || id.trim().isEmpty()){
        Toast.makeText(this,"ID obrigatorio", Toast.LENGTH_LONG).show();
        return;
    }
    RequestQueue queue = Volley.newRequestQueue(this);
        String url ="http://192.168.1.101:8080/api/restaurant/mesa/"+id;
    StringRequest stringRequest = new StringRequest(
            Request.Method.GET, url,
            ok -> tratarPostResposta(ok) , erro -> tratarErro(erro));
    queue.add(stringRequest);
    //0
}


//tratamento de resposta
private void tratarErro(VolleyError erro) {
    String mensagem = "Erro desconhecido";
    if (erro.networkResponse != null) {
        mensagem = "Código HTTP: " + erro.networkResponse.statusCode
                + " - " + new String(erro.networkResponse.data);
    }
    Toast.makeText(this, mensagem, Toast.LENGTH_LONG).show();
}
    private void tratarPostResposta(String ok) {
        tratarResposta(ok);
    }
    private void tratarResposta(String json) {
        try{
            EditText nomeET = findViewById(R.id.editText_Produto);
            EditText quantidadeET = findViewById(R.id.editText_quantidade);
            EditText valorET = findViewById(R.id.editText_Valor);
            EditText clienteET = findViewById(R.id.editText_Cliente);

            JSONObject obj = (JSONObject) new JSONTokener(json).nextValue();
            clienteET.setText(obj.getString("cliente"));
            JSONArray pedidoArray = obj.getJSONArray("pedido");
            JSONObject primeiroPedido = pedidoArray.getJSONObject(0);
            String nome = primeiroPedido.getString("nomeProduto");
            int quantidade = primeiroPedido.getInt("quantidade");
            double valor = primeiroPedido.getDouble("valor");

            ListView listView = findViewById(R.id.listView_mesa);
            ArrayList<String> itens = new ArrayList<>();
            itens.add("Produto: " + nome + " | Total: R$ " + obj.getDouble("valorConta"));
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itens);
            listView.setAdapter(adapter);

        }catch (Exception ex){
            Toast.makeText(this,"Error" + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
//Fim do tratamento de resposta

}//fim da classe